export const baseURL = "YOUR_SERVER_PATH"; // example: https://example.example.com

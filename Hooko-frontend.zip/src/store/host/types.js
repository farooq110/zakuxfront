export const GET_HOST = "GET_HOST";
export const ENABLE_DISABLE_HOST = "ENABLE_DISABLE_HOST";
